# YouTube Subscription Plugin
This plugin will connect the youtube channel with the site. It will show the number of total subscriptions. Once clicked, it will redirect to the given youtube channel.

# Title
This will display the text on the website. Appears on top of the widget div.

# Channel
This is where user put the channel id; Retrieved from https://www.youtube.com/account_advanced

# Count
User can show or hide the count (number of subscribers)


### Version
0.0.1

### Author
Iftekhar Ahmed

### Plugin Site
theme.valancers.com